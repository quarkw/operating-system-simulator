package user_interface;

import java.io.IOException;

public class ShellConsole {
    public static void main(String[] args) throws IOException {
        Shell shell = new Shell();
        shell.start();
    }
}
